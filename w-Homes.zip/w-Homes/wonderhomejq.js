
	
		
				
					$(function(){
					
						
						$("#homes1").click(function(){
							$("#homepage").show(3000);
							$("#bhomes1").hide(3000);
							$("#cottages1").hide(3000);
							$("#hhouses1").hide(3000);
							$("#beach").hide(3000);
							$("#cottage").hide(3000);
							$("#haunted").hide(3000);
							$(".b").show(3000);
							$("#villasimg").hide(3000);
							$("#villa").hide(3000);
						})
						$("#bhomes").click(function(){
							$("#homepage").hide(3000);
							$("#bhomes1").show(3000);
							$("#cottages1").hide(3000);
							$("#hhouses1").hide(3000);
							$("#beach").show(3000);
							$("#cottage").hide(3000);
							$("#haunted").hide(3000);
							$(".b").hide(3000);
							$("#villasimg").hide(3000);
							$("#villa").hide(3000);
						})
						
						$("#cottages").click(function(){
							$("#homepage").hide(3000);
							$("#bhomes1").hide(3000);
							$("#cottages1").show(3000);
							$("#hhouses1").hide(3000);
							$("#beach").hide(3000);
							$("#cottage").show(3000);
							$("#haunted").hide(3000);
							$(".b").hide(3000);
							$("#villasimg").hide(3000);
							$("#villa").hide(3000);
						})
					
						$("#hhouses").click(function(){
							$("#homepage").hide(3000);
							$("#bhomes1").hide(3000);
							$("#cottages1").hide(3000);
							$("#hhouses1").show(3000);
							$("#beach").hide(3000);
							$("#cottage").hide(3000);
							$("#haunted").show(3000);
							$(".b").hide(3000);
							$("#villasimg").hide(3000);
							$("#villa").hide(3000);
						})
					$("#villab").click(function(){
							$("#homepage").hide(3000);
							$("#bhomes1").hide(3000);
							$("#cottages1").hide(3000);
							$("#hhouses1").hide(3000);
							$("#beach").hide(3000);
							$("#cottage").hide(3000);
							$("#haunted").hide(3000);
							$(".b").hide(3000);
							$("#villasimg").show(3000);
							$("#villa").show(3000);
						})
					
					
					
					});
				
		
	