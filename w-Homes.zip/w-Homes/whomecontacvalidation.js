
				$(function(){
					$("#submit").click(function(){
					var name=$("#name").val().trim();
					var mobile=$("#mobile").val().trim();
					var city=$("#city").val().trim();
					
					if(name=="")
					{
						$("#name").css("border","2px solid red");
						$("#nameerror").text("Please Enter Your Name").css("color","red");
					}
					else
					{
						$("#name").css("border","2px solid green");
						$("#nameerror").text("");
					}
					if(mobile=="")
					{
						$("#mobile").css("border","2px solid red");
						$("#mobileerror").css("color","red").text("Please Enter Your Mobile No,");
					}
					else
					{
						$("#mobile").css("border","2px solid green");
						$("#mobileerror").text("");
					}
					if(city=="")
					{
						$("#city").css("border","2px solid red");
						$("#cityerror").css("color","red").text("Please Enter Your City");
					}
					else
					{
						$("#city").css("border","2px solid green");
						$("#cityerror").text("");
					}
					})	
				
				});
		